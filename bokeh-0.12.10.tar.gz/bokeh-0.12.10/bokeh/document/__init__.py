'''


'''
from __future__ import absolute_import

from .document import Document ; Document

from .document import DEFAULT_TITLE ; DEFAULT_TITLE

from .locking import without_document_lock ; without_document_lock
