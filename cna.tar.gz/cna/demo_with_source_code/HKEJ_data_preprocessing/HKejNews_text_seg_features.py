#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Jan  8 11:39:20 2018

Introduction: This programe is developed to generate various features from the text segment

@author: astri
"""

import pandas as pd


# load the corporation identity term dictionary
corp_terms_df = pd.read_csv(corp_terms_path, sep = '\t')


length = []
for val in seg_df.text_seg:
    length.append(len(val))
seg_df['length'] = length


out_df = pd.DataFrame()

def label_text_seg_type(row):
    '''
    three types of text segs:
        type 0: normal
        type 1: short seg and it is not a title
        type 2: disclaimer
    '''
    # set the default seg type is 0
    text_seg_type = 0
    # a user defined disclaimer dictionary
    disclaimerTerms = set(['免责声明', '数据截至', '本资料所述', '本资料之内容', '更新日期及时间', '版权所有', '重要声明'])
    # condition for type 1
    if ((row['text_seg_id'][-2:] != 'P0') and (len(row.text_seg) < 15)):
        text_seg_type = 1
    # condition for type 2
    elif any([st in row.text_seg for st in disclaimerTerms]) and row['text_seg_seq'] == row['tot_text_seg']:
        text_seg_type = 2
    return text_seg_type

seg_df['text_seg_type'] = seg_df.apply(lambda row:label_text_seg_type(row), axis=1)


# count the number of mentioned identity terms (relative to the target corporation) which appearance in each segmention
def count_company_mentioned_freq(row):
    company_name = row['company']
    terms = corp_terms_df.Terms[corp_terms_df.Name == company_name]
    if len(terms) > 0:
        terms = (list(terms)[0]).split('-')
        count_num = [row['text_seg'].count(term) for term in terms]
        company_mentioned_freq = sum(count_num)
    else:
        company_mentioned_freq = 0
    return(company_mentioned_freq)
    
## testing case
#count_company_mentioned_freq(seg_df.iloc[4000])

seg_df['company_mentioned_freq'] = seg_df.apply(count_company_mentioned_freq, axis = 1)

# calculate the company_mentioned_freq for unit length
seg_df['Freq/length'] = seg_df['company_mentioned_freq'] / seg_df['length']


# output the well-fit training set
seg_df.to_csv(outfile_path, sep = "\t", index = False)