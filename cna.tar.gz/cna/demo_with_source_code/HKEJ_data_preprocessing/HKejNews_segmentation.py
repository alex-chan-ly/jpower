# -*- coding: utf-8 -*-
"""
Created on Fri Jan 19 13:54:32 2018

Introduction: this is a sub program use for text segmentation

@author: astri
"""

# load the require libs
import pandas as pd
# import string
import re

# get the data set after filtering the HKej noisy news
# infile_df = pd.read_csv('news_filtered.csv', delimiter = "\t")
HKej_keep_df = infile_df.query('keep_or_skip  == "keep"')


# define the function to segment each news
def textsplit(row):
    text = row['text']

    # seperate by empty space, represented by "\xa0":
    splitParts = text.split("\xa0")
    splitParts = list(filter(None, splitParts))

    n = len(splitParts)
    paragraphs = [row['title']]
    # reconstruct the paragraph due to outlier cases
    longparaFlag = False
    for i in range(n):
        longparaFlag = False
        if(len(splitParts[i])>500):
            text = text.replace('」 '," ")
            text = text.replace('？ ', "。 ")
            temp = text.split("。 ")
            temp = list(filter(None, temp))

            paragraphs.append(temp[0] + "。")
            for j in range(len(temp)-1):
                if j == len(temp)-2 and len(temp[j+1])<100:
                    paragraphs[-1] = paragraphs[-1] + temp[j + 1] + "。"
                    break

                if (len(paragraphs[-1])<300) and (len(temp[j+1])<100):
                    paragraphs[-1] = paragraphs[-1]+temp[j+1]+"。"
                else:
                    paragraphs.append(temp[j+1]+"。")
            longparaFlag = True
            break

    # paragraphs.append(splitParts[0])
    #
    # if n > 1:
    #     for i in range(n-1):
    #
    #         if splitParts[i][-1] == "。":
    #             paragraphs.append(splitParts[i + 1])
    #         elif not (splitParts[i][-1] in ascii) and not (splitParts[i + 1][0] in ascii):
    #             paragraphs.append(splitParts[i + 1])
    #         else:
    #             paragraphs[-1] = paragraphs[-1] + " " + splitParts[i + 1]
    if not longparaFlag:
        for i in range(n):
            paragraphs.append(splitParts[i])
                
    n = len(paragraphs)

    articleIndx = row.url.split('/')[-2]
    if articleIndx == 'articleDetail':
        articleIndx = row.url.split('=')[-1]
    elif not articleIndx.isdigit():
        articleIndx = row.url.split('/')[-1]

    index = ["HKej_"+ row['Company']+ articleIndx + "_P"+ str(i) for i in range(n)]
    date = re.findall(r'\d+', row.time)
    if(date != []): #deal with invalid date time
        if(int(date[0])>1000):
            date = "{:4d}{:02d}{:02d}".format(int(date[0]), int(date[1]), int(date[2]))
        else:
            date = 00000000
    else:
        date = 00000000
    segdf = pd.DataFrame({'text_seg_id':index,
                          'text_seg_seq': [i+1 for i in range(n)],
                          'tot_text_seg': [n for i in range(n)],
                          'text_seg':paragraphs,
                          'title':[row['title'] for i in range(n)],
                          'url':[row['url'] for i in range(n)],
                          'data_source': [row['data_source'] for i in range(n)],
                          'company':[row['Company'] for i in range(n)],
                          'keywords': [row['keywords'] for i in range(n)],
                          'date': [date for i in range(n)]})
    return(segdf)


seg_df = pd.DataFrame()
for j in range(len(HKej_keep_df)):
    temp = textsplit(HKej_keep_df.iloc[j])
    temp['text_seg_id_sort_id'] = [len(seg_df)+i+1 for i in range(len(temp))]

    seg_df = seg_df.append(temp, ignore_index = True)
    
# export the segments if necessary
# seg_df.to_csv('data/seg_df.csv', sep = "\t", index = False)