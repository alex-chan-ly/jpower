#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Jan  8 11:39:20 2018

Introduction: This programe is developed to process the news data from HKej news
data source, it finally generates the segments for training  

@author: astri
"""
# load the require libs
import pandas as pd

# load the preprocessing configration file
conf_df = pd.read_csv("preprocessing_conf.csv", sep = "\t")

# news data file path
infile_path = conf_df.loc[conf_df['config_parm'] == "infile_path"]['value'].iloc[0]
infile_delimiter = conf_df.loc[conf_df['config_parm'] == "infile_delimiter"]['value'].iloc[0]

# the news filtering rules file path
rule_file_path = conf_df.loc[conf_df['config_parm'] == "news_filter_rule_file_path"]['value'].iloc[0]
rule_file_delimiter = conf_df.loc[conf_df['config_parm'] == "news_filter_rule_file_delimiter"]['value'].iloc[0]
# label_column = conf_df.loc[conf_df['config_parm'] == "label_column"]['value'].iloc[0]

# the corporation terms file path
corp_terms_path = conf_df.loc[conf_df['config_parm'] == "corp_terms_path"]['value'].iloc[0]
corp_terms_delimiter = conf_df.loc[conf_df['config_parm'] == "corp_terms_delimiter"]['value'].iloc[0] 

# the training data output path
outfile_path = conf_df.loc[conf_df['config_parm'] == "outfile_path"]['value'].iloc[0]
outfile_delimiter = conf_df.loc[conf_df['config_parm'] == "outfile_delimiter"]['value'].iloc[0]

# CSV file delimiter amending 
if "\\t".lower() in infile_delimiter.lower() or "tab".lower() in infile_delimiter.lower():
    infile_delimiter = "\t"

if "comma".lower() in infile_delimiter.lower():
    infile_delimiter = ","
    
if "\\t".lower() in outfile_delimiter.lower() or "tab".lower() in outfile_delimiter.lower():
    outfile_delimiter = "\t"

if "comma".lower() in outfile_delimiter.lower():
    infile_delimiter = ","
    
if "\\t".lower() in rule_file_delimiter.lower() or "tab".lower() in rule_file_delimiter.lower():
    rule_file_delimiter = "\t"

if "comma".lower() in rule_file_delimiter.lower():
    rule_file_delimiter = ","    
    
if "\\t".lower() in corp_terms_delimiter.lower() or "tab".lower() in corp_terms_delimiter.lower():
    corp_terms_delimiter = "\t"

if "comma".lower() in corp_terms_delimiter.lower():
    corp_terms_delimiter = ","
        

# excute sub-preprocessing programs one by one    
# Step 1: filter the news 
exec(open("HKejNews_news_filtering.py").read(), globals())

# Step 2: segment the news text  
exec(open("HKejNews_segmentation.py").read(), globals())

# Step 3: label the segments 
exec(open("HKejNews_text_seg_features.py").read(), globals())
