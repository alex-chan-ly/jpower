# -*- coding: utf-8 -*-
"""
Created on Thu Jan 11 17:34:25 2018

Introduction: this sub program is developed to filter out useless news from HKej 
data source base on the filtering rule file 

@author: astri
"""

# load the require libs
import pandas as pd
import re
from hanziconv import HanziConv

# define the Chinese character type (simplified or traditional) before text processing
chType = "S"   # "T": stands for tranditional Chinese, "S": stands for simplified Chinese 



# load the raw news data set and unify all the chinese characters as simplified Chinese 
# or traditional Chinese (default is simplified Chinese)
infile_df = pd.read_csv(infile_path, delimiter = infile_delimiter)
infile_df = infile_df.fillna("NULL")

# Define the columns which are needed to unified
cols = list(infile_df.columns)
# targetCols = ["keywords", "title", "text", "author"]
targetCols = ["title", "text", "author"]
targetIndex = [cols.index(st) for st in targetCols]

def preprocess(row, targetCol, chType):
    # remove the quotion sign
    st = row[targetCol]
    if st.startswith('"'):
        st = st[1:]
    if st.endswith('"'):
        st = st[:-1]
    # unify the Chinese character (simplisified or traditional)
    st_s = HanziConv.toSimplified(st)
    st_t = HanziConv.toTraditional(st_s)
    if chType == "S":
        return(st_s)
    else:
        return(st_t)   

for j in targetCols:
    infile_df[j] = infile_df.apply(preprocess, axis = 1, args = (j, chType))
    


# load the news filtering rule file
rule_df = pd.read_csv(rule_file_path, delimiter = rule_file_delimiter)
rule_df = rule_df.fillna("NULL")
# convert the value column into the defined Chinese character type
if chType == "S":
    rule_df['value'] = [HanziConv.toSimplified(val) for val in rule_df.value]
else:
    rule_df['value'] = [HanziConv.toTraditional(val) for val in rule_df.value]


        
# define the filtering function based on the rule file
def type_classify(row):
    # a variable to store the news type, the default value is "HKej_keep" 
    news_type = "keep"     
    
    # check every filtering condition in the rule_df:         
    for i in range(rule_df.shape[0]):
        pattern = rule_df.pattern[i]
        field = rule_df.field[i]
        value_str = rule_df.value[i]
      
        if field != 'NULL':  # any pattern except 'else'   
            field_str = row[field]
            # transform the special characters in field_str into comman ones
            # note: this situation happens in HKej news
            trans_field_str = ""
            for char_loc in range(0, len(field_str)):
                sub_char = field_str[char_loc]
                if sub_char == "０":
                    sub_char = "0"
                if sub_char == "１":
                    sub_char = "1"
                if sub_char == "２":
                    sub_char = "2"
                if sub_char == "３":
                    sub_char = "3"
                if sub_char == "４":
                    sub_char = "4"
                if sub_char == "５":
                    sub_char = "5"
                if sub_char == "６":
                    sub_char = "6"
                if sub_char == "７":
                    sub_char = "7"
                if sub_char == "８":
                    sub_char = "8"
                if sub_char == "９":
                    sub_char = "9"
                if sub_char == "（":
                    sub_char = "("
                if sub_char == "）":
                    sub_char = ")"
                trans_field_str = trans_field_str + sub_char            
            field_str = trans_field_str
            
            # apply the filtering rule
            if pattern == 'match':
                if field_str == value_str:
                    news_type = rule_df.keep_or_skip[i]
            elif pattern == 'contain':
                if value_str in field_str:
                    news_type = rule_df.keep_or_skip[i]
            elif pattern == 'reg_match':
                # parse the value_str when the pattern is 'reg_match'
                # note: when the definition of reg_match chages, the following 
                # parsing codes must change.
                value_str = value_str.split(sep = ' more_than ')
                reg_pattern = value_str[0]
                threshold_num = int(value_str[1])
                # find out all the matched pattern and compare with the threshold_num
                match_patterns = re.findall(reg_pattern, field_str)
                if len(match_patterns) > threshold_num:
                    news_type = rule_df.keep_or_skip[i]

    return(news_type)

     
infile_df['keep_or_skip'] = infile_df.apply(type_classify, axis = 1)    



# export the labelled news if necessary
# infile_df.to_csv('data/news_filtered.csv', sep = "\t", index = False)

