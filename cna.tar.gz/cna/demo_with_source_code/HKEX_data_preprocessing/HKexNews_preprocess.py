#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 16:14:05 2018

@author: ming
"""

import pandas as pd
import os
import re


infile_path = ""
infile_delimiter = ""
outfile_path = ""
outfile_delimiter = ""
rule_file_path = ""
label_column = "news_type"

conf_file = "preprocessing_conf.csv"
conf_df = pd.read_csv(conf_file,sep = "\t")

infile_path = conf_df.loc[conf_df['config_parm'] == "infile_path"]['value'].iloc[0]
infile_delimiter = conf_df.loc[conf_df['config_parm'] == "infile_delimiter"]['value'].iloc[0]
outfile_path = conf_df.loc[conf_df['config_parm'] == "outfile_path"]['value'].iloc[0]
outfile_delimiter = conf_df.loc[conf_df['config_parm'] == "outfile_delimiter"]['value'].iloc[0]
rule_file_path = conf_df.loc[conf_df['config_parm'] == "news_filter_rule_file_path"]['value'].iloc[0]
label_column = "keep_or_skip"
label_to_keep = "keep"
pdf_dir = conf_df.loc[conf_df['config_parm'] == "pdf_dir"]['value'].iloc[0]

if "\\t".lower() in infile_delimiter.lower() or "tab".lower() in infile_delimiter.lower():
    infile_delimiter = "\t"

if "comma".lower() in infile_delimiter.lower():
    infile_delimiter = ","
    
if "\\t".lower() in outfile_delimiter or "tab".lower() in outfile_delimiter:
    outfile_delimiter = "\t"

if "comma".lower() in outfile_delimiter.lower():
    infile_delimiter = ","

print ("Filter news type:")
pwd = os.getcwd()
exec(open("HKexNews_news_filtering.py").read())

print ("Text segmentation:")
news_sumy_pd = data_pd[data_pd["keep_or_skip"] == "keep"]
news_sumy_pd = news_sumy_pd.reset_index(drop=True)
train_set_dir = pwd
PDF_dir = pdf_dir
exec(open("HKexNews_segmentation.py").read())

print ("Label text segment type:")
text_seg_pd = train_set_pd
outfile = outfile_path
exec(open("HKexNews_label_text_seg_type.py").read())