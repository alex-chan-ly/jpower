#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 28 09:46:09 2017

@author: ming
"""

import pandas as pd
import re
import os
import curses.ascii

#train_set_dir = "/home/ming/Desktop/Link_to_project/2017/HSBC_GRA/deliverable/data"
#infile = train_set_dir + "/HKexNews_text_seg.csv"
#outfile = train_set_dir + "/HKexNews_trainset.csv"

#text_seg_pd = pd.read_csv(infile, delimiter="\t")

punct_str = "$(,<@`|#'+/;?[_{&*.:>^~!%)-=]}"
punct_set = set(punct_str)

def label_text_seg_type(row):
    text_seg_type = 0
    text_seg = row['text_seg']
    title = row['title']

    text_seg = text_seg.replace('Mr. ','Mr ')
    text_seg = text_seg.replace('Ms. ','Ms ')
    text_seg = text_seg.replace('Mrs. ','Mrs ')
    text_seg = text_seg.replace('Dr. ','Dr ')    
    text_seg = text_seg.replace('‘‘','“')
    text_seg = text_seg.replace('’’','”')
    
#    text_seg_utf8 = text_seg.decode("utf-8")
#    temp_text_seg_utf8 = ''
#    for i in range(0,len(text_seg_utf8)):
#        if not re.match(ur'[\u4e00-\u9fff]+',text_seg_utf8[i]):
#            temp_text_seg_utf8 = temp_text_seg_utf8 + text_seg_utf8[i]    
#    text_seg = temp_text_seg_utf8.encode('UTF-8')

    temp_replace_set = set(re.findall("[0-9],[0-9]", text_seg))
    for temp_replace_old in temp_replace_set:
        temp_replace_new = temp_replace_old.replace(",",'')
        text_seg = text_seg.replace(temp_replace_old,temp_replace_new)      
    temp_replace_set = set(re.findall("[0-9].[0-9]", text_seg))
    for temp_replace_old in temp_replace_set:
        temp_replace_new = temp_replace_old.replace(".",'_')
        text_seg = text_seg.replace(temp_replace_old,temp_replace_new)

    temp_replace_old = re.match("[\-—–]+ *[0-9]+ *[\-—–]+ *",text_seg)
    if temp_replace_old:
        text_seg = text_seg[len(temp_replace_old.group(0)):]
        
    if "." not in text_seg and \
    "," not in text_seg and \
    ";" not in text_seg and \
    ":" not in text_seg:
        text_seg_type = 2
    
    if len(text_seg) < 50:
        text_seg_type = 3
    
    if not re.search("[a-z]",text_seg):
        text_seg_type = 4

    digit_num = 0
    for c in text_seg:
        if c.isdigit() or c in punct_set:
            digit_num = digit_num + 1
    if digit_num >= len(text_seg)/4:
        text_seg_type = 5
        
    if "______" in text_seg.lower() or \
    re.search(" \. \. \. \. \.", text_seg):
        text_seg_type = 6
        
    if re.match("“.+” ", text_seg[0:150]):
        text_seg_type = 7
    if re.match('".+" ', text_seg[0:150]):
        text_seg_type = 7
    if re.match("'.+' ", text_seg[0:150]):
        text_seg_type = 7
    if re.match("“.+”\.", text_seg[0:150]):
        text_seg_type = 7
    if re.match('".+"\.', text_seg[0:150]):
        text_seg_type = 7
    if re.match("'.+'\.", text_seg[0:150]):
        text_seg_type = 7
        
    if re.search("stock code: +[0-9]+",text_seg.lower()) and \
    "liability)" in text_seg.lower() and \
    len(text_seg) < 200:
        text_seg_type = 8
        
    if "exchanges and clearing limited" in text_seg.lower() and \
    "stock exchange" in text_seg.lower() and \
    "take no responsibility for the contents" in text_seg.lower():
        text_seg_type = 9

    if re.match("by order of ", text_seg.lower()):
        text_seg_type = 10
        
    if "yours faithfully" in text_seg[0:50].lower():
        text_seg_type = 10

    if "for identification purpose" in text_seg.lower() and \
    len(text_seg) < 100:
        text_seg_type = 10
        
    if row['text_seg_seq'] >= row['tot_text_seg'] - 3 and \
    "as at the date of" in text_seg[0:50].lower():
        text_seg_type = 10
                
    if re.search(', the People’s Republic of China [0-9]{0,2} [A-Z][a-z]+ [0-9]{2,4}', text_seg) and \
    len(text_seg) < 300:
        text_seg_type = 11
        
    if re.match("Hong Kong, [0-9]+ [A-Z][a-z]+ [0-9]{2,}", text_seg) and \
    len(text_seg) < 300:
        text_seg_type = 11
        
    if title.lower() == text_seg.lower() or "[title]: " in text_seg:
        text_seg_type = 1
        
    text_seg_type = "HKex_type_" + str(text_seg_type)
    return text_seg_type
    
text_seg_pd['text_seg_type'] = text_seg_pd.apply(lambda row:label_text_seg_type(row), axis=1)

col_list = ['text_seg_sort_id',
            'text_seg_id',
            'data_source', 
            'company',
            'url', 
            'date', 
            'title',
            'tot_text_seg',
            'text_seg_seq',
            'text_seg',
            'text_seg_type']

text_seg_pd.to_csv(outfile, header=True, columns = col_list, sep = '\t', index = False)
