#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 21 16:40:17 2017

@author: ming
"""

import pandas as pd
import re
import os
import curses.ascii

#infile = "/home/ming/Desktop/Link_to_project/2017/HSBC_GRA/deliverable/pgm/python3/HKexNews_keep.csv"
#news_sumy_pd = pd.read_csv(infile, delimiter="\t")
#train_set_dir = "/home/ming/Desktop/Link_to_project/2017/HSBC_GRA/deliverable/pgm/python3"
#outfile = train_set_dir + "/HKexNews_text_seg.csv"
#PDF_dir = "/home/ming/Desktop/Link_to_project/2017/HSBC_GRA/deliverable/data/HKexNews"

train_set_col_list = ['text_seg_id',
                      'data_source',
                      'company',
                      'url',
                      'date',
                      'title',
                      'text_seg_seq',
                      'text_seg']
                      
train_set_pd = pd.DataFrame(columns = train_set_col_list)

os.system("mkdir " + train_set_dir + "/temp")

#for i in range(0,10):
for i in range(0,news_sumy_pd.shape[0]):
    if i%10 == 0:
        print ("Text segmentation at news " + str(i))
    stock_code = news_sumy_pd.iloc[i]['stock_code']
    filename = news_sumy_pd.iloc[i]['file']

    data_source = "HKEX"
    company =  news_sumy_pd.iloc[i]['customer_english_name']
    url =  news_sumy_pd.iloc[i]['link']
    date = news_sumy_pd.iloc[i]['date']
    title = news_sumy_pd.iloc[i]['title']
    title = title.replace('\t',' ')
    title = title.replace('"', "'" )
    title = title.replace("\\", "/" )
    temp_title = ''
    for j in range(0,len(title)):
        c = title[j]
        if not curses.ascii.iscntrl(c):
            temp_title = temp_title + c            
    title = temp_title
    title = title.strip()
    
    text_seg_id = ""
    
    if filename[-4:] == ".pdf":
#        print (filename)
        temp_path = PDF_dir + "/" + filename
        pdftotext_cmd = "pdftotext " + temp_path + " -layout " + train_set_dir + "/temp/"  + filename[:-4]+".txt"
        os.system(pdftotext_cmd)
        
        lines = []
        text_segs = []
        text_seg = ""
        with open(train_set_dir + "/temp/"  + filename[:-4]+".txt") as f:
            line = f.readline()
            lines.append(line)
            while (line):
                line = f.readline()
                temp_line = re.sub(' {2,}', ' ', line)
                temp_line = temp_line.replace('•','')
                temp_line = temp_line.rstrip("\n\r")
                temp_line = temp_line.strip()
                
                if re.match('[\-—–]* *[0-9]+ *[\-—–]*',temp_line) and re.match('[\-—–]* *[0-9]+ *[\-—–]*',temp_line).group(0) == temp_line:
                    temp_line = ""
                lines.append(temp_line)
                
        for i in range(0,len(lines)):
            temp_line = lines[i]
            text_seg = text_seg + " " + temp_line
            if temp_line == "":
                text_segs.append(text_seg)
                text_seg = ""
        
        for i in range(0,len(text_segs)):
            text_seg = text_segs[i]
            text_seg = text_seg.replace("\n","")
            text_seg = text_seg.replace("\r","")
            text_seg = text_seg.strip()
            text_segs[i] = text_seg
        
        text_seg_cnt = 1
        if len(title) > 0:
            text_seg = "[title]: " + title
            text_seg_seq = text_seg_cnt
            text_seg_cnt = text_seg_cnt + 1
            text_seg_id = data_source + "_" + filename[:-4] + "_s" + str(text_seg_seq)
            temp_df = pd.DataFrame([[text_seg_id,
                                     data_source, 
                                     company,
                                     url,
                                     date,
                                     title,
                                     text_seg_seq,
                                     text_seg]],
                                     columns=train_set_col_list)
            train_set_pd = train_set_pd.append(temp_df, ignore_index=True)      
        
        for i in range(0,len(text_segs)):
            text_seg = text_segs[i]
            if len(text_seg) > 0:
                text_seg_seq = text_seg_cnt
                text_seg_cnt = text_seg_cnt + 1
                text_seg = text_seg.replace('\t', ' ' )
                text_seg = text_seg.replace('"', "'" )
                text_seg = text_seg.replace("\\", "/" )
                temp_text_seg = ''
                for j in range(0,len(text_seg)):
                    c = text_seg[j]
                    if not curses.ascii.iscntrl(c):
                        temp_text_seg = temp_text_seg + c            
                text_seg = temp_text_seg
                         
                text_seg_id = data_source + "_" + filename[:-4] + "_s" + str(text_seg_seq)
                temp_df = pd.DataFrame([[text_seg_id,
                                         data_source, 
                                         company,
                                         url,
                                         date,
                                         title,
                                         text_seg_seq,
                                         text_seg]],
                                         columns=train_set_col_list)
                train_set_pd = train_set_pd.append(temp_df, ignore_index=True)
        os.system("rm " + train_set_dir + "/temp/"  + filename[:-4]+".txt")
        
temp_group_by = train_set_pd.groupby(['url'], sort=False)['text_seg_seq'].max()
temp_df = pd.DataFrame({'url':list(temp_group_by.index), 'tot_text_seg':list(temp_group_by)})
train_set_pd = pd.merge(train_set_pd, temp_df, how='left', on = 'url')

train_set_pd['text_seg_sort_id'] = train_set_pd.index + 1
train_set_col_list = ['text_seg_sort_id',
                      'text_seg_id',
                      'data_source', 
                      'company',
                      'url', 
                      'date', 
                      'title',
                      'tot_text_seg',
                      'text_seg_seq',
                      'text_seg']

#train_set_pd.to_csv(outfile_path, sep='\t', header=True, columns = train_set_col_list, index = False)

os.system("rm " + train_set_dir + "/temp/*.txt")
os.system("rmdir " + train_set_dir + "/temp")
