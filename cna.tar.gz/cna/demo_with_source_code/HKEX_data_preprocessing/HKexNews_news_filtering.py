# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 09:17:34 2018

@author: ming
"""

import pandas as pd
import os
    
infile_df = pd.read_csv(infile_path, delimiter = infile_delimiter)
infile_field_set = set(infile_df.columns)
infile_field_set.add('else')

rule_py = open("apply_rule.py", 'w')
rule_py.write('import pandas as pd\n')
rule_py.write('import re\n')
rule_py.write('data_pd = pd.read_csv("'+ infile_path+'", delimiter="'+infile_delimiter +'")\n')
rule_py.write('def label_data(row):\n')
rule_py.write('\t'+label_column+' = ""\n')

rule_df = pd.read_csv(rule_file_path,sep="\t")
rule_df = rule_df.fillna("NULL")
field_set = set()
for i in range(0,rule_df.shape[0]):
    rule_row = rule_df.iloc[i]
    field = rule_row['field'].lower()
    field_set.add(field)
    
for field in field_set:
    if not field == "null" and field in infile_field_set:
        rule_py.write('\t' + field + ' = row["' + field + '"]\n')
        rule_py.write('\t' + field + ' = str('+field+').lower()\n')    
    
for i in range(0,rule_df.shape[0]):
    rule_row = rule_df.iloc[i]
    field = rule_row['field'].lower()
    pattern = rule_row['pattern'].lower()
    value = rule_row['value'].lower()
    label = rule_row['keep_or_skip']

    if field in infile_field_set:
        if pattern == "ignore":
            rule_line_1 = field + ' = ' + field + '.replace("' + value + '","")'
            rule_py.write('\t' + rule_line_1 + '\n')
            
        if pattern == "start":
            rule_line_1 = 'if ' + field + '[0:len("' + value + '")] == "' + value +'":'
            rule_line_2 = '\t' + label_column+ ' = "' + label + '"'
            rule_py.write('\t' + rule_line_1 + '\n')
            rule_py.write('\t' + rule_line_2+'\n')
        if pattern == "contain":
            rule_line_1 = 'if "' + value + '" in ' + field + ':'
            rule_line_2 = '\t' + label_column+ ' = "' + label + '"'
            rule_py.write('\t' + rule_line_1 + '\n')
            rule_py.write('\t' + rule_line_2+'\n')
        if pattern == "match":
            rule_line_1 = 'if re.match("'+value+'",' + field + '):'
            rule_line_2 = '\t' + label_column+ ' = "' + label + '"'
            rule_py.write('\t' + rule_line_1 + '\n')
            rule_py.write('\t' + rule_line_2+'\n')
        if pattern == "empty":
            rule_line_1 = 'if '+ field + '.rstrip().strip() == "nan":'
            rule_line_2 = '\t' + label_column+ ' = "' + label + '"'
            rule_py.write('\t' + rule_line_1 + '\n')
            rule_py.write('\t' + rule_line_2+'\n')         
    if pattern == "else":
        rule_line_1 = 'if '+ label_column + ' == "":'
        rule_line_2 = '\t' + label_column+ ' = "' + label + '"'
        rule_py.write('\t' + rule_line_1 + '\n')
        rule_py.write('\t' + rule_line_2+'\n')
rule_py.write('\treturn ' + label_column + '\n')

rule_py.write('data_pd["' + label_column + '"] = data_pd.apply(lambda row:label_data(row), axis = 1)\n')
#rule_py.write('data_pd.to_csv("' + outfile_path +'", sep = "' + outfile_delimiter + '", index = False)')
rule_py.close()

exec(open("apply_rule.py").read())
os.system('rm apply_rule.py')