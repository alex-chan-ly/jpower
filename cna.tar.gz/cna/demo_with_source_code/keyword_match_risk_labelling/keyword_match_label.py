#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  9 15:13:27 2018

@author: ming
"""

import pandas as pd
import re
from hanziconv import HanziConv

conf_file = "keyword_match_conf.csv"
conf_df = pd.read_csv(conf_file,sep = "\t")

infile = conf_df.loc[conf_df['config_parm'] == "infile_path"]['value'].iloc[0]
text_field = conf_df.loc[conf_df['config_parm'] == "text_field"]['value'].iloc[0]
dictfile = conf_df.loc[conf_df['config_parm'] == "dictfile_path"]['value'].iloc[0]
outfile = conf_df.loc[conf_df['config_parm'] == "outfile_path"]['value'].iloc[0]

#infile = '/home/ming/Desktop/Link_to_project/2017/HSBC_GRA/deliverable/pgm/python3/labeling/train.csv'
#dictfile = '/home/ming/Desktop/Link_to_project/2017/HSBC_GRA/deliverable/pgm/python3/labeling/risk_dict.csv'
#outfile = '/home/ming/Desktop/Link_to_project/2017/HSBC_GRA/deliverable/pgm/python3/labeling/risk_label.csv'

data_df = pd.read_csv(infile, sep = '\t')
dict_df = pd.read_csv(dictfile, sep = '\t')

topic_set = set()
for i in range(0,dict_df.shape[0]):
    row = dict_df.loc[i]
    topic_set.add(row['topic'])

# Matching in English
topic_term_dict = {}
for topic in topic_set:
    term_set = set()
    topic_term_dict[topic] = term_set

for i in range(0,dict_df.shape[0]):
    row = dict_df.loc[i]
    topic = row['topic']
    term = row['term']
    # filter chinese terms
    if not re.match('[\u4e00-\u9fff]', term):
        topic_term_dict[topic].add(term.lower())

def label_topic_eng(row, field, term_set):
    is_label = 0
    search_text = str(row[field]).lower()
    for term in term_set:
        if re.search("\W" + term, " " + search_text):
            is_label = 1
    return is_label

for topic in topic_term_dict.keys():
    term_set = topic_term_dict[topic]
#    print (topic)
    data_df[topic + "_eng"] = data_df.apply(lambda row:label_topic_eng(row, text_field, term_set), axis=1)

# Matching in Chinese
topic_term_dict = {}
for topic in topic_set:
    term_set = set()
    topic_term_dict[topic] = term_set

for i in range(0,dict_df.shape[0]):
    row = dict_df.loc[i]
    topic = row['topic']
    term = row['term']
    # filter English terms
    test_term = re.sub("[A-z]", "" ,term)
    test_term = re.sub("[’ .,\/#!$%\^&\*;:{}=\-_`~()]", "" ,test_term)    
    if test_term != '':
        term = HanziConv.toSimplified(term)
        topic_term_dict[topic].add(term)

def label_topic_cn(row, field, term_set):
    is_label = 0
    search_text = str(row[field])
    search_text = HanziConv.toSimplified(search_text)
    for term in term_set:
        if re.search(term, search_text):
            is_label = 1
    return is_label

for topic in topic_term_dict.keys():
    term_set = topic_term_dict[topic]
#    print (topic)
    data_df[topic + "_cn"] = data_df.apply(lambda row:label_topic_cn(row, text_field, term_set), axis=1)

def merge_eng_cn_label(row, topic):
    is_label = 0
    if row[topic + "_eng"] > 0:
        is_label = 1
    if row[topic + "_cn"] > 0:
        is_label = 1
    return is_label

for topic in topic_term_dict.keys():
    data_df[topic] = data_df.apply(lambda row:merge_eng_cn_label(row, topic), axis=1)
    data_df = data_df.drop([topic + "_eng", topic + "_cn"], axis=1)

data_df.to_csv(outfile, sep = '\t', index = False)